import React from 'react';

import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
} from 'react-native';

class AddContactForm extends React.Component {

  state = {
    name: '',
    phone: '',
    isFormValid: false,
  };

  // Validate whenever name or phone changes
  componentDidUpdate(prevProps, prevState) {

    if (
      this.state.name !== prevState.name ||
      this.state.phone !== prevState.phone
    ) {
      this.validateForm();
    }
  }

  // Common input handler
  getHandler = key => val => {

    this.setState({
      [key]: val,
    });

  };

  // Name handler
  handleNameChange = this.getHandler('name');

  // Phone handler
  handlePhoneChange = this.getHandler('phone');

  // Form validation
  validateForm = () => {

    const nameValid =
      /^[A-Za-z]+ [A-Za-z]+$/.test(
        this.state.name
      );

    const phoneValid =
      /^[0-9]{10}$/.test(
        this.state.phone
      );

    if (nameValid && phoneValid) {

      this.setState({
        isFormValid: true,
      });

    } else {

      this.setState({
        isFormValid: false,
      });

    }
  };

  // Submit form
  handleSubmit = () => {

    this.props.onSubmit({
      name: this.state.name,
      phone: this.state.phone,
    });

  };

  render() {

    return (
      <View style={styles.container}>

        <Text style={styles.title}>
          Add Contact
        </Text>

        {/* Name */}
        <Text style={styles.label}>
          Name
        </Text>

        <TextInput
          style={styles.input}
          value={this.state.name}
          onChangeText={this.handleNameChange}
          placeholder="First Name Last Name"
          autoCapitalize="words"
        />

        {/* Phone */}
        <Text style={styles.label}>
          Phone
        </Text>

        <TextInput
          keyboardType="numeric"
          style={styles.input}
          value={this.state.phone}
          onChangeText={this.handlePhoneChange}
          placeholder="10 digit phone number"
          maxLength={10}
        />

        {/* Add Button */}
        <Button
          title="Add"
          onPress={this.handleSubmit}
          disabled={!this.state.isFormValid}
        />

      </View>
    );
  }
}

const styles = StyleSheet.create({

  container: {
    backgroundColor: '#ffffff',
    padding: 20,
    margin: 10,
    borderRadius: 10,
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: '#999999',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    fontSize: 16,
  },

});

export default AddContactForm;